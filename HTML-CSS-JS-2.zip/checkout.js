// Initialize Stripe
const stripe = Stripe('your-publishable-key'); // Replace with your publishable key
const elements = stripe.elements();

// Create an instance of the card element
const card = elements.create('card', {
  style: {
    base: {
      fontSize: '16px',
      color: '#32325d',
      '::placeholder': { color: '#aab7c4' },
    },
    invalid: { color: '#fa755a' },
  },
});
card.mount('#card-element');

// Handle form submission
const form = document.getElementById('payment-form');
form.addEventListener('submit', async (event) => {
  event.preventDefault();

  const { error, paymentIntent } = await stripe.confirmCardPayment(
    'your-client-secret', // Replace with the client secret from your backend
    {
      payment_method: { card: card },
    }
  );

  if (error) {
    // Display error
    const errorElement = document.getElementById('card-errors');
    errorElement.textContent = error.message;
  } else {
    // Payment successful
    alert('Payment successful!');
  }
});