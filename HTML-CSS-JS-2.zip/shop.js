document.addEventListener("DOMContentLoaded", () => {
  const productItems = document.querySelectorAll(".product-item");

  productItems.forEach(item => {
    item.addEventListener("click", () => {
      const title = item.getAttribute("data-title");
      const image = item.getAttribute("data-image");
      const description = item.getAttribute("data-description");
      const price = item.getAttribute("data-price");

      // Redirect to the checkout page with product details as query parameters
      const queryParams = `?title=${encodeURIComponent(title)}&image=${encodeURIComponent(image)}&description=${encodeURIComponent(description)}&price=${encodeURIComponent(price)}`;
      window.location.href = `checkout.html${queryParams}`;
    });
  });
});