<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $first_name = htmlspecialchars($_POST['first_name']);
  $last_name = htmlspecialchars($_POST['last_name']);
  $email = htmlspecialchars($_POST['email']);
  $message = htmlspecialchars($_POST['message']);

  // Email configuration
  $to = "your-email@example.com"; // Replace with your email
  $subject = "New Contact Form Submission from $first_name $last_name";
  $body = "Name: $first_name $last_name\nEmail: $email\n\nMessage:\n$message";
  $headers = "From: $email";

  // Send email
  if (mail($to, $subject, $body, $headers)) {
    echo "Thank you for your message! We will get back to you shortly.";
  } else {
    echo "Sorry, something went wrong. Please try again.";
  }
}
?>