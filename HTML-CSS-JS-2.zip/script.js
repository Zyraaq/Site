// Sample video data (YouTube URL, Thumbnail, Title)
const videos = {
  latest: [
    { title: "Latest Video 1", url: "https://m.youtube.com/watch?v=qvCgadMBKhU&pp=ygULV2VlZCByZXZpZXc%3D", thumbnail: "https://img.youtube.com/vi/dQw4w9WgXcQ/0.jpg" },
    { title: "Latest Video 2", url: "https://www.youtube.com/watch?v=V-_O7nl0Ii0", thumbnail: "https://img.youtube.com/vi/V-_O7nl0Ii0/0.jpg" }
  ],
  interesting: [
    { title: "Interesting Video 1", url: "https://www.youtube.com/watch?v=Vj4q1XIQdso", thumbnail: "https://img.youtube.com/vi/Vj4q1XIQdso/0.jpg" },
    { title: "Interesting Video 2", url: "https://www.youtube.com/watch?v=Qs7Z8vHDXYI", thumbnail: "https://img.youtube.com/vi/Qs7Z8vHDXYI/0.jpg" }
  ],
  howto: [
    { title: "How-To Video 1", url: "https://www.youtube.com/watch?v=Hj4G4ZK9bYs", thumbnail: "https://img.youtube.com/vi/Hj4G4ZK9bYs/0.jpg" },
    { title: "How-To Video 2", url: "https://www.youtube.com/watch?v=fKQFVxIfk8E", thumbnail: "https://img.youtube.com/vi/fKQFVxIfk8E/0.jpg" }
  ],
  podcast: [
    { title: "Podcast Video 1", url: "https://www.youtube.com/watch?v=KZl8sZmGO4k", thumbnail: "https://img.youtube.com/vi/KZl8sZmGO4k/0.jpg" },
    { title: "Podcast Video 2", url: "https://www.youtube.com/watch?v=FY8vL7Okv1o", thumbnail: "https://img.youtube.com/vi/FY8vL7Okv1o/0.jpg" }
  ]
};

// Function to populate video categories with cards
const populateVideos = () => {
  const categories = ['latest', 'interesting', 'howto', 'podcast'];

  categories.forEach(category => {
    const container = document.getElementById(`${category}-videos`);
    videos[category].forEach(video => {
      const card = document.createElement('div');
      card.classList.add('video-card');
      card.innerHTML = `
        <img src="${video.thumbnail}" alt="${video.title}">
        <h4>${video.title}</h4>
      `;
      card.addEventListener('click', () => openVideo(video.url));
      container.appendChild(card);
    });
  });
};

// Function to open video in modal
const openVideo = (url) => {
  const videoId = url.split('v=')[1];
  const iframeSrc = `https://www.youtube.com/embed/${videoId}?autoplay=1`;
  document.getElementById('videoIframe').src = iframeSrc;
  document.getElementById('videoModal').style.display = 'flex';
};

// Close video modal
document.getElementById('closeModal').addEventListener('click', () => {
  document.getElementById('videoModal').style.display = 'none';
  document.getElementById('videoIframe').src = '';  // Stop the video when modal is closed
});

// Populate videos on page load
populateVideos();